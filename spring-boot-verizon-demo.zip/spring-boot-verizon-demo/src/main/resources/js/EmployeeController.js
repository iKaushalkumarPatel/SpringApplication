'use strict';
 
angular.module('verizonEmpApp').controller('EmployeeController',
    ['EmployeeService', '$scope',  function( EmployeeService, $scope) {
 
        var self = this;
        self.employee = {};
        self.employees=[];
 
        self.submit = submit;
        self.getAllEmployee = getAllEmployee;
        self.createEmployee = createEmployee;
        self.updateEmployee = updateEmployee;
        self.removeEmployee = removeEmployee;
        self.editEmployee = editEmployee;
        self.reset = reset;
 
        self.successMessage = '';
        self.errorMessage = '';
        self.done = false;
 
        self.onlyIntegers = /^\d+$/;
        self.onlyNumbers = /^\d+([,.]\d+)?$/;
 
        function submit() {
            console.log('Submitting');
            if (self.employee.id === undefined || self.employee.id === null) {
                console.log('Saving New employee', self.employee);
                createemployee(self.employee);
            } else {
                updateemployee(self.employee, self.employee.id);
                console.log('employee updated with id ', self.employee.id);
            }
        }
 
        function createemployee(employee) {
            console.log('About to create employee');
            employeeService.createemployee(employee)
                .then(
                    function (response) {
                        console.log('employee created successfully');
                        self.successMessage = 'employee created successfully';
                        self.errorMessage='';
                        self.done = true;
                        self.employee={};
                        $scope.myForm.$setPristine();
                    },
                    function (errResponse) {
                        console.error('Error while creating employee');
                        self.errorMessage = 'Error while creating employee: ' + errResponse.data.errorMessage;
                        self.successMessage='';
                    }
                );
        }
 
 
        function updateemployee(employee, id){
            console.log('About to update employee');
            employeeService.updateemployee(employee, id)
                .then(
                    function (response){
                        console.log('employee updated successfully');
                        self.successMessage='employee updated successfully';
                        self.errorMessage='';
                        self.done = true;
                        $scope.myForm.$setPristine();
                    },
                    function(errResponse){
                        console.error('Error while updating employee');
                        self.errorMessage='Error while updating employee '+errResponse.data;
                        self.successMessage='';
                    }
                );
        }
 
 
        function removeemployee(id){
            console.log('About to remove employee with id '+id);
            employeeService.removeemployee(id)
                .then(
                    function(){
                        console.log('employee '+id + ' removed successfully');
                    },
                    function(errResponse){
                        console.error('Error while removing employee '+id +', Error :'+errResponse.data);
                    }
                );
        }
 
 
        function getAllemployees(){
            return employeeService.getAllemployees();
        }
 
        function editemployee(id) {
            self.successMessage='';
            self.errorMessage='';
            employeeService.getemployee(id).then(
                function (employee) {
                    self.employee = employee;
                },
                function (errResponse) {
                    console.error('Error while removing employee ' + id + ', Error :' + errResponse.data);
                }
            );
        }
        function reset(){
            self.successMessage='';
            self.errorMessage='';
            self.employee={};
            $scope.myForm.$setPristine(); //reset Form
        }
    }
    ]);