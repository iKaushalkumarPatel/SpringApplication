/**
 * 
 */
package controller;

import java.util.List;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
 
import model.Employee;
import services.EmployeeServices;
import repositories.EmployeeRepository;

/**
 * @author ei335165
 *
 */
public class RestApiController {

	public static final Logger logger = LoggerFactory.getLogger(RestApiController.class);
	 
    @Autowired
    EmployeeServices employeeServices; //Service which will do all CRUD operations on employee data
 
    // -------------------Retrieve All Employee---------------------------------------------
 
    @RequestMapping(value = "/employee/", method = RequestMethod.GET)
    public ResponseEntity<List<Employee>> listAllUsers() {
        List<Employee> employee = EmployeeServices.findAllEmployee();
        if (employee.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
            // You many decide to return HttpStatus.NOT_FOUND
        }
        return new ResponseEntity<List<Employee>>(employee, HttpStatus.OK);
    }
 
    // -------------------Add Employee-------------------------------------------
 
    @RequestMapping(value = "/employee/", method = RequestMethod.POST)
    public ResponseEntity<?> addEmployee(@RequestBody Employee employee, UriComponentsBuilder ucBuilder) {
        logger.info("Creating User : {}", employee);
 
        if (EmployeeServices.isEmployeeExist(employee)) {
            logger.error("Unable to create. A User with name {} already exist", employee.getEmpFirstName());
            return new ResponseEntity(new CustomErrorType(),HttpStatus.CONFLICT);
        }
        EmployeeServices.addEmployee(employee);
 
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/api/user/{id}").buildAndExpand(employee.getEmp_Id()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }
 
    // ------------------- Update Employee ------------------------------------------------
 
    @SuppressWarnings({ "unchecked", "rawtypes" })
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.PUT)
    public ResponseEntity<?> updateEmployee(@PathVariable("id") long id, @RequestBody Employee employee) {
        logger.info("Updating User with id {}", id);
 
        Employee currentEmployee = EmployeeServices.findByName(employee);
 
        if (currentEmployee == null) {
            logger.error("Unable to update. User with id {} not found.", id);
            return new ResponseEntity(new CustomErrorType(),
                    HttpStatus.NOT_FOUND);
        }
 
        currentEmployee.setEmp_Id(employee.getEmp_Id());
        currentEmployee.setEmpFirstName(employee.getEmpFirstName());
        currentEmployee.setEmpLastName(employee.getEmpLastName());
        currentEmployee.setEmpCity(employee.getEmpCity());
        currentEmployee.setEmpState(employee.getEmpState());
        currentEmployee.setEmpCountry(employee.getEmpCountry());
        return new ResponseEntity<Employee>(HttpStatus.OK);
    }
 
    // ------------------- Delete Employee-----------------------------------------
 
    @SuppressWarnings("unchecked")
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteEmployee(@PathVariable("id") long id) {
        logger.info("Fetching & Deleting User with id {}", id);
 
        Employee employee = EmployeeServices.findById(id);
        if (employee == null) {
            logger.error("Unable to delete. User with id {} not found.", id);
            return new ResponseEntity(new CustomErrorType(),
                    HttpStatus.NOT_FOUND);
        }
        EmployeeServices.deleteEmployee(id);
        return new ResponseEntity<Employee>(HttpStatus.NO_CONTENT);
    }
}
