/**
 * 
 */
package services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.Employee;
import repositories.EmployeeRepository;

/**
 * @author ei335165
 *
 */
@Service("EmployeeServices")
@Transactional
public abstract class EmployeeServicesImpl implements EmployeeServices {
	
	public void addEmployee(Employee employee){
    	EmployeeRepository.add(employee);
    }

    public void updateEmployee(Employee employee){
    	EmployeeRepository.updateEmployee(employee);
    }

    public void deleteEmployee(Long emp_Id){
    	EmployeeRepository.deleteEmployee(emp_Id);
    }

    public void saveEmployee(Employee employee) {
    	EmployeeRepository.saveEmployee(employee);
    }    

    public Employee findById(Long empId){
    	return EmployeeRepository.findById(empId);	
    }
    public Employee findByName(String empFirstName) {
        return EmployeeRepository.findByName(empFirstName);
    }    
}
