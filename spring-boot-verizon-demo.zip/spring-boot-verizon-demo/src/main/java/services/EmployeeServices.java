/**
 * 
 */
package services;

/**
 * @author ei335165
 *
 */
import com.*;

import model.Employee;
import com.SpringBootVerizonApp;
import java.util.List;

public interface EmployeeServices {

	public static void addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}
	public void updateEmployee(Employee employee);
	public static void deleteEmployee(Long id) {
		// TODO Auto-generated method stub
		
	}
	public void saveEmployee(Employee employee);
	public static List<Employee> findAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}
    static Employee findById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
    static Employee findByName(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}
    static boolean isEmployeeExist(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}
}
