package com;
/**
 * 
 */

import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author ei335165
 *
 */

import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import configurations.JpaConfiguration;
import services.EmployeeServices;
 

 
 
@Import(JpaConfiguration.class)
@SpringBootApplication 
@ComponentScan
@ComponentScan(basePackages = { "com" })
@EnableJpaRepositories("com.EmployeeRepository")
public class SpringBootVerizonApp {
	
	 @Autowired
	 EmployeeServices employeeServices;	

	    public static void main(String[] args) {  
	        SpringApplication.run(SpringBootVerizonApp.class, args);  
	    }  
}
