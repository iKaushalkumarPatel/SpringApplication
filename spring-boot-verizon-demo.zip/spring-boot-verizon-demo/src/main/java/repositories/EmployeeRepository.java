package repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
 

	public void addEmployee(Employee employee);

	public static void deleteEmployee(Long emp_Id) {
		// TODO Auto-generated method stub
		
	}
	public static void saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}
	public static List<Employee> findAllEmployee() {
		// TODO Auto-generated method stub
		return null;
	}
    static Employee findById(Long emp_Id) {
		// TODO Auto-generated method stub
		return null;
	}
    static Employee findByName(String empFirstName) {
		// TODO Auto-generated method stub
		return null;
	}
    boolean isEmployeeExist(Employee employee);
	public static void add(Employee employee) {
		// TODO Auto-generated method stub
		
	}
	public static void updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
	}

}