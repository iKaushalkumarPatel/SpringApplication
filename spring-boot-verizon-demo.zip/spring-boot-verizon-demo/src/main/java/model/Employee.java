package model;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name="EMPLOYEE")
public class Employee implements Serializable{

	@Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
	
	@NotEmpty
    @Column(name="EMP_ID", nullable=false)
	private String emp_Id;
	
	@NotEmpty
    @Column(name="EMP_FIRST_NAME", nullable=false)
	private String empFirstName;
	
	@NotEmpty
    @Column(name="EMP_LAST_NAME", nullable=false)
	private String empLastName;
	
	@NotEmpty
    @Column(name="EMP_CITY", nullable=false)
	private String empCity;
	
	@NotEmpty
    @Column(name="EMP_STATE", nullable=false)
	private String empState;

	@NotEmpty
    @Column(name="EMP_COUNTRY", nullable=false)
	private String empCountry;


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getEmp_Id() {
		return emp_Id;
	}


	public void setEmp_Id(String emp_Id) {
		this.emp_Id = emp_Id;
	}


	public String getEmpFirstName() {
		return empFirstName;
	}


	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}


	public String getEmpLastName() {
		return empLastName;
	}


	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}


	public String getEmpCity() {
		return empCity;
	}


	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}


	public String getEmpState() {
		return empState;
	}


	public void setEmpState(String empState) {
		this.empState = empState;
	}


	public String getEmpCountry() {
		return empCountry;
	}


	public void setEmpCountry(String empCountry) {
		this.empCountry = empCountry;
	}


	public void printHello() {
		System.out.println("Hello ! " + empFirstName);
	}	

}
